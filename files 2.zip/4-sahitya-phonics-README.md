# Sahitya

**Learning to read, delivered on WhatsApp.**

![Demo](docs/demo.gif)

## The problem

Millions of children are taught by teachers and parents who have a phone but no reading curriculum, and dyslexia often goes unnoticed.

## What I built

A structured phonics curriculum with dyslexia screening, delivered as daily lesson plans on WhatsApp.

## Result

- Used in **104 Anganwadis** (government childcare centres) and Euro International Schools
- Adopted by **two partner organisations in Nigeria and Uganda**
- **11,500+** reached
- **Technovation Girls Global Semifinalist**
- Run by Sahitya-Siksha Foundation, a registered non-profit

## Built with

**Claude Code** (AI coding assistant) · WhatsApp

## My role

I founded Sahitya, wrote the curriculum, and designed the dyslexia screening. I built the lesson-delivery app with my Technovation Girls team, and I work with our partners in India, Nigeria and Uganda.

**Website:** LINK
