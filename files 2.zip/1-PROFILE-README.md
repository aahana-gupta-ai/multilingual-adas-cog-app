# Aahana Gupta

**I build tools that make memory tests, care and learning work in people's own languages.**

My research showed that a standard dementia memory test, designed in English, can misread Indian patients. Everything below grew from that: the app I built to test it properly, a care product for families living with dementia, and a reading programme for children.

**Currently:** scaling SmritiCare from 400 to 1,145 families · 120-patient paper under review at the *Journal of Clinical Neuroscience*

---

### Research → tool → product → community

**1. The research.** 120-patient study of cultural and language bias in the ADAS-Cog dementia test, with Prof. Vijay Kumar Chattu. Under review, *Journal of Clinical Neuroscience*. Built on my first paper, published in *Bioinformation* with Dr. Praveen Gupta, Marengo Asia Hospital.

**2. The tool.** [Multilingual ADAS-Cog App](https://github.com/YOUR-USERNAME/multilingual-adas-cog-app): gives the test in 4 Indian languages; collected all 120 patients' data.

**3. The product.** [SmritiCare](https://github.com/YOUR-USERNAME/smriticare): dementia care in the cloned voices of patients' own families. 400 families · Provisional Patent IN 202611038483 · Endorsed by the Union Health Minister of India.

**4. The community.** [Sahitya](https://github.com/YOUR-USERNAME/sahitya-phonics): WhatsApp-native phonics and dyslexia screening. 11,500+ reached across India, Nigeria and Uganda · Technovation Girls Global Semifinalist.

**And for the love of it:** [Ancient Greek Musical Systems](https://github.com/YOUR-USERNAME/greek-music-wolfram): frequency ratios and a reconstructed lyre, hand-written in Wolfram Language. Wolfram Staff Pick.

---

### How I build

I write code by hand (Wolfram Language) and use AI coding tools (Claude Code, Manus) for apps. Every README says which tool built what. I design each tool, test it with real users, and can explain every file here.

**Tools:** Wolfram Language · Claude Code · Manus · ElevenLabs · WhatsApp

📄 [Full CV](CV.md) · 📖 [*The Wrong Words*](AMAZON-LINK) · 📰 [Economic Times feature](ET-LINK)
