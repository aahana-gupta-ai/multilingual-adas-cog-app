# Aahana Gupta — CV

Cardiff Sixth Form College, Class of 2027 · A-levels: Biology, Mathematics, Psychology, Chemistry
Intended study: Cognitive Science (AI and language)

## Research

**Lead Researcher & App Developer** — Cultural bias in dementia testing, 120-patient study, with Prof. Vijay Kumar Chattu
Built a multilingual app giving the ADAS-Cog test in 4 Indian languages; collected all study data. Under review, *Journal of Clinical Neuroscience*.

**Lead Researcher** — ADAS-Cog Performance in Urban Indian Alzheimer's Patients, with Dr. Praveen Gupta, Marengo Asia Hospital
First peer-reviewed paper, published in *Bioinformation*.

**Researcher & Intern** — Psychiatry & Mental Health, Fortis Memorial Research Institute, Gurugram, under Dr. Samir Parikh
Analysed Alzheimer's clinical datasets; examined where DSM-5 frameworks diverge from culturally shaped symptoms.

**Student Researcher** — Wolfram Summer Research Program, Bentley University
Computational essay on ancient Greek musical systems. Staff Pick; invited to TA and to the Wolfram Emerging Leaders Program.

## Building

**Founder & Sole Developer — SmritiCare**
Dementia care through family voice clones (ElevenLabs, WhatsApp). 400 families, scaling to 1,145. Provisional Patent IN 202611038483. Endorsed by the Union Health Minister of India.

**Founder & Developer — Sahitya (Sahitya-Siksha Foundation)**
WhatsApp-native phonics curriculum with dyslexia screening. 104 Anganwadis, Euro International Schools, partner organisations in Nigeria and Uganda; 11,500+ reached.

## Writing

**The Wrong Words** (ISBN 978-81-994235-0-3), co-authored with Dr. Deepak Rathod
How Western diagnostic tools misclassify non-Western patients. Raised $3,500 for physician training in culturally adapted dementia assessment.

## Leadership

**President, Psychology Club; Founder, Cardiff's first IYNA chapter** — Cardiff Sixth Form College
Created the "Invisible Assumptions" AI-bias exhibition and 10 awareness campaigns.

**Founder & Host — "Notes for the Future" open mics and "Fuel a Dream" campaign**
Raised ₹4.91 lakh for children's education.

## Honours

- Cambridge Re:think Essay Competition — Silver (top 0.25% of 15,000+)
- Technovation Girls — Global Semifinalist
- UKMT Senior Mathematical Challenge — Gold; Mathematical Olympiad for Girls — Distinction
- Haryana Health Minister Award — youngest recipient
- Wolfram Summer Research Program — Staff Pick

## Music

Trinity College London: Grade 6 Rock & Pop Vocals, Grade 5 Piano · House Vocalist, Morgan House (Eisteddfod)
