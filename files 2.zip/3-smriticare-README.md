# SmritiCare

**Dementia care in the voices patients trust most: their own family's.**

![Demo](docs/demo.gif)

## The problem

People with dementia often respond best to familiar voices, but family can't always be there.

## What I built

An app that clones a family member's voice and uses it to talk with the patient over WhatsApp, with conversations tuned to the patient's ADAS-Cog memory profile. I also built the website.

## Result

- **400 families** served; scaling to **1,145**
- Endorsed by the **Union Health Minister of India**
- **Provisional Patent IN 202611038483**

## Built with

**Claude Code** (AI coding assistant) · ElevenLabs (voice cloning) · WhatsApp

## My role

Sole developer. I came up with SmritiCare, designed how it works, built the app and website, and ran it with families.

**Website:** LINK
