# Ancient Greek Musical Systems

**What did ancient Greek music sound like? I calculated it, then rebuilt the lyre to hear it.**

![Preview](docs/preview.png)

## What I built

A computational essay in Wolfram Language that models the frequency ratios behind ancient Greek scales and reconstructs the lyre, so the scales can be heard, not just calculated.

## Result

- **Wolfram Staff Pick**
- Invited back as a Teaching Assistant and to the Wolfram Emerging Leaders Program

Written at the Wolfram Summer Research Program, Bentley University.

## Built with

**Wolfram Language, written entirely by hand.**

## My role

I chose the question, wrote all of the code, and wrote the essay.

**Published essay:** LINK
